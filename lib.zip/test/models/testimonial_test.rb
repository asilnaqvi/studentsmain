require 'test_helper'

class TestimonialTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
