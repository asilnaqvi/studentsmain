require 'test_helper'

class RolesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
