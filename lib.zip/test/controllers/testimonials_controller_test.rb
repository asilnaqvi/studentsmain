require 'test_helper'

class TestimonialsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
