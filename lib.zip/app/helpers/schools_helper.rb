module SchoolsHelper
end
