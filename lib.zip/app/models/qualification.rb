class Qualification < ActiveRecord::Base
	has_many :teachers
end
